import math
import random
import sys
import matplotlib.pyplot as plt
import pathlib
import numpy as np
sys.path.append(str(pathlib.Path(__file__).parent.parent))
sys.path.append(str(pathlib.Path(__file__).parent))

from RRT.rrt import RRT
from RRTStar import upsample
from RRTStar import rrt_star


def gengoal(obstacle_list,min_dist=0):

    p = (round(random.uniform(-1,1),3), round(random.uniform(-1,1),3))

    collision = False
    for obst in obstacle_list:  # obst = [x,y,size(radius)]
        if( (obst[0] - p[0])**2 + (obst[1] - p[1])**2 <= (obst[2] + min_dist)**2 ):
            collision = True

    if(collision):
        p = gengoal(obstacle_list=obstacle_list,min_dist=min_dist)

    return p



def main():

    obstacle_list = [ (0,0,1), (0.5,0.5,0.5)]

    min_traj_len = 0.1

    start = gengoal(obstacle_list=obstacle_list,min_dist=0.05)

    goal = gengoal(obstacle_list=obstacle_list,min_dist=0.05)

    while( (start[0]-goal[0])**2 + (start[1]-goal[1])**2 < min_traj_len):
        goal = gengoal(obstacle_list=obstacle_list,min_dist=0.05)



    print("start : ",start, "\n" + "goal : ", goal)

    # ====Search Path with RRT====
    obstacle_list = [
        (-1/2, 1/2, 0.3),
        (2/3,0,0.3),
        (-1/6,-1/2,0.3)

    ]  # [x,y,size(radius)]


    start = (-0.75,-0.75)
    goal = (0.75,-0.75)

    # Set Initial parameters
    rrtobj = rrt_star.RRTStar(
        start=start,
        goal=goal,
        rand_area=[-1, 1],
        obstacle_list=obstacle_list,
        expand_dis=0.1,
        robot_radius=0.05,
        path_resolution=0.02,
        max_iter=1000)


    iet_per_sample = 1000

    min_len = math.inf
    for _ in range(iet_per_sample):
        path = rrtobj.planning(animation=False)

        # print(path)


        if path is None:
            print("Cannot find path")
        else:
            # print("found path!!")

            num_waypoints = 384
            pathres = 0.02
            (samples,l_traj) = upsample.generate_samples(path,num_waypoints,pathres)


            if(len(samples)!=num_waypoints):
                # print("invalid traj length (", len(samples),"), skipping")
                continue


            if(l_traj < min_len):
                traj = samples
                min_len = l_traj



            # plt.plot([x for (x, y) in samples], [y for (x, y) in samples])
            # plt.grid(True)
            # plt.xlim([-1,1])
            # plt.ylim([-1,1])

    print(min_len)

    for (ox, oy, size) in obstacle_list:
        deg = list(range(0, 360, 5))
        deg.append(0)
        xl = [ox + size * math.cos(np.deg2rad(d)) for d in deg]
        yl = [oy + size * math.sin(np.deg2rad(d)) for d in deg]
        plt.plot(xl, yl)

        plt.plot(start[0],start[1],marker="s")
        plt.plot(goal[0],goal[1],marker="o")

    plt.plot([x for (x, y) in traj], [y for (x, y) in traj])
    plt.grid(True)
    plt.xlim([-1,1])
    plt.ylim([-1,1])
    
    plt.show()  




if __name__ == '__main__':
    main()