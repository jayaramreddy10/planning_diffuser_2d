from .sobol import i4_sobol as sobol_quasirand
